package com.company.controller;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
* здесь производится ввод строк с консоли
*/

import java.io.BufferedReader;
import java.io.InputStreamReader;

import static com.company.view.View.toMes2;

public class Controller {
    private static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    private static String reader;

    public static String[] Controller(){

        try {
            reader = bufferedReader.readLine();                          //чтение данных с консоли
        } catch (Exception e) {
            return null;
        }
        String[] arrays = reader.split(" ");                      //разделение строки на слова
        if(reader.equals("exit")) System.exit(0);                //если строка равна "exit" -> выход из программы
        if(arrays.length != 5) {                                        //проверка количества слов в массиве
            toMes2("Input data in format: \"а V = b W\"");
            return null;
        }
        return arrays;
    }
}
