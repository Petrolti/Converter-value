package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

public class convBPyramid{
    private static String b;
    public static final String name = "pyramid";     //Имя класса

    public static String convB(String a, String w){
        double c = Double.parseDouble(a);
        switch (w) {
            case "bar":
                b = Double.toString(c * 1.4);
                break;
            case "ring":
                b = Double.toString(c * 8.4);
                break;
            default:
                b = null;
        }
        return b;
    }
}
