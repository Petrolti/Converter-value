package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

import com.company.controller.Controller;
import static com.company.view.View.toMes2;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
* здесь производится основная обработка данных
*/


public class Model {                                                    //Основной алгоритм программы
    public static void Model() {                                        //
        String[] array = Controller.Controller();                       //Получение массива данных со входа

        if (array != null) {                                   //Производится проверка массива на наличине в нем данных
            String a = array[0].toLowerCase();                    //получение входной переменной в строковую переменную
            String V = array[1].toLowerCase();                          //получение типа входной переменной
            String b;                                                   //определение выходной переменной
            String W = array[4].toLowerCase();                          //получение типа выходной переменной

            switch (V){                    //в зависимости от типа входной переменной вызываются соответствующие модули
                case convBByte.name : b = convBByte.convB(a,W); break;
                case convBKiloByte.name : b = convBKiloByte.convB(a,W); break;
                case convBBite.name : b = convBBite.convB(a,W); break;
                case convBRing.name : b = convBRing.convB(a,W); break;
                case convBHare.name : b = convBHare.convB(a,W); break;
                case convBCat.name : b = convBCat.convB(a,W); break;
                case convBPyramid.name : b = convBPyramid.convB(a,W); break;
                case convBGiraffe.name : b = convBGiraffe.convB(a,W); break;
                case convBBar.name : b = convBBar.convB(a,W); break;
                default : b = null;      //если нет соответствующего типа выводится сообщение "Conversion not possible."
            }
            if (b == null) toMes2("Conversion not possible.");
            else toMes2(a + " " + V + " = " + b + " " + W);

        } else toMes2("Conversion not possible.");
    }
}
