package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/
public class convBByte{
    private static String b;                      //Выходная переменная
    public static final String name = "byte";     //Имя класса

    public static String convB(String a, String w){
        int c;
        try {
             c = Integer.parseInt(a);
        } catch (Exception e) {
            return null;
        }
        switch (w) {
            case "kb":
            case "kilobyte":
                b = Integer.toString((int) c / 1024);
                break;
            case "kilobite":
                b = Integer.toString((int) c * 8 / 1024);
                break;
            case "bite":
                b = Integer.toString(c * 8) ;
                break;
            default:
                b = null;
        }
        return b;
    }
}