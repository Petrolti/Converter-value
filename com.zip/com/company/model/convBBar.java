package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

public class convBBar{
    private static String b;
    public static final String name = "bar";     //Имя класса

    public static String convB(String a, String w){
        double c = Double.parseDouble(a);
        switch (w) {
            case "ring":
                b = Double.toString(c * 6);
                break;
            case "pyramid":
                b = Double.toString(c / 1.4);
                break;
            default:
                b = null;
        }
        return b;
    }
}
