package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

public class convBKiloByte{
    private static String b;
    public static final String name = "kilobyte";     //Имя класса

    public static String convB(String a, String w){
        int c;
        try {
            c = Integer.parseInt(a);
        } catch (Exception e) {
            return null;
        }
        switch (w) {
            case "byte":
                b = Integer.toString(c * 1024);
                break;
            case "bit":
                b = Integer.toString(c * 1024 * 8);
                break;
            default:
                b = null;
        }
        return b;
    }
}

