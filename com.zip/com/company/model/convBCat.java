package com.company.model;

public class convBCat{
    private static String b;
    public static final String name = "cat";     //Имя класса

    public static String convB(String a, String w){
        double c = Double.parseDouble(a);
        switch (w) {
            case "hare":
                b = Double.toString(c * 4);
                break;
            case "giraffe":
                b = Double.toString(c * 0.1);
                break;
            default:
                b = null;
        }
        return b;
    }
}
