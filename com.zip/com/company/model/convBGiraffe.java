package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

public class convBGiraffe {
    private static String b;
    public static final String name = "giraffe";     //Имя класса

    public static String convB(String a, String w){
        double c = Double.parseDouble(a);
        switch (w) {
            case "cat":
                b = Double.toString(c * 10);
                break;
            case "hare":
                b = Double.toString(c * 40);
                break;
            default:
                b = null;
        }
        return b;
    }
}
