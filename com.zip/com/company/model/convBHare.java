package com.company.model;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

public class convBHare{
    private static String b;
    public static final String name = "hare";     //Имя класса

    public static String convB(String a, String w){
        double c = Double.parseDouble(a);
        switch (w) {
            case "cat":
                b = Double.toString(c / 4);
                break;
            case "giraffe":
                b =Double.toString(c * 40) ;
                break;
            default:
                b = null;
        }
        return b;
    }
}
