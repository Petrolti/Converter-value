package com.company.view;
/*
* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
* Здесь производится вывод строк в консоль
*/

public class View {
    public static void toMes1(String string){
        System.out.print(string);
    }
    public static void toMes2(String string){
        System.out.println(string);
    }
}
