package com.company;

/*
Задание на программирование:
Дан перевод некоторых величин в формате a V = b W, где a, b – числа; V, W – названия величин (могут быть любые),
следом дана последовательность с неизвестным вторым числом в формате a V = ? W, необходимо найти величину,
обозначенную в пропорции знаком вопроса.
Ввод данных и вывод результата осуществляются через стандартные потоки ввода/вывода.
Выходной формат a V = b W. Каждое равенство пишется на отдельной строке.

Пример:
1024 byte = 1 kilobyte
2 bar = 12 ring
16.8 ring = 2 pyramid
4 hare = 1 cat
5 cat = 0.5 giraffe
1 byte = 8 bit
15 ring = 2.5 bar

Вход:
1 pyramid = ? bar
1 giraffe = ? hare
0.5 byte = ? cat
2 kilobyte = ? bit

Выход:
1 pyramid = 1.4 bar
1 giraffe = 40 hare
Conversion not possible.
2 kilobyte = 16384 bit

* Программа разработана для компании VDCOM программистом Petrolti (Петров Олег Тимофеевич). 2017
*/

import java.io.IOException;

import static com.company.model.Model.Model;
import static com.company.view.View.toMes2;

public class Main {

    public static void main(String[] args) {
        toMes2("");
        toMes2("\tConverter value for VDCOM (test version by Petrolti)");
        toMes2("\tInput data in format: \"а V = b W\"");
        toMes2("\tto out write \"exit\"");
        while(true){
            Model();
        }
    }
}
